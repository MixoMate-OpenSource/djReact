/* eslint-disable no-undef */
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import { VitePWA } from "vite-plugin-pwa";
import { compression } from "vite-plugin-compression2";
import { join } from "node:path";
import { buildSync } from "esbuild";
// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      injectRegister: "auto",
      includeAssets: [
        "icon-72x72.png",
        "apple-touch-icon.png",
        "mask-icon.png",
      ],
      manifest: {
        name: "HRMS",
        short_name: "hrms",
        theme_color: "#1976d2",
        background_color: "#fafafa",
        display: "standalone",
        scope: "./",
        start_url: "./",
        icons: [
          // {
          //   src: "/assets/icons/icon-72x72.png",
          //   sizes: "72x72",
          //   type: "image/png",
          //   purpose: "maskable any",
          // },
          // {
          //   src: "/assets/icons/icon-96x96.png",
          //   sizes: "96x96",
          //   type: "image/png",
          //   purpose: "maskable any",
          // },
          // {
          //   src: "/assets/icons/icon-128x128.png",
          //   sizes: "128x128",
          //   type: "image/png",
          //   purpose: "maskable any",
          // },
          // {
          //   src: "/assets/icons/icon-144x144.png",
          //   sizes: "144x144",
          //   type: "image/png",
          //   purpose: "maskable any",
          // },
          // {
          //   src: "/assets/icons/icon-152x152.png",
          //   sizes: "152x152",
          //   type: "image/png",
          //   purpose: "maskable any",
          // },
          {
            src: "/assets/icons/icon-192x192.png",
            sizes: "192x192",
            type: "image/png",
            purpose: "maskable any",
          },
          // {
          //   src: "/assets/icons/icon-384x384.png",
          //   sizes: "384x384",
          //   type: "image/png",
          //   purpose: "maskable any",
          // },
          {
            src: "/assets/icons/icon-512x512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "maskable any",
          },
        ],
      },
      workbox: {
        clientsClaim: true,
        skipWaiting: true,
        maximumFileSizeToCacheInBytes: 10 * 1024 * 1024, // Example: Set maximum file size to 10MB
        // Customize caching strategies as needed
        // strategies: [...],
        // swDest: "public/sw.js",
      },
      devOptions: {
        enabled: true,
        /* other options */
      },
    }),
    {
      apply: "build",
      enforce: "post",
      transformIndexHtml() {
        buildSync({
          minify: true,
          bundle: true,
          // entryPoints: [join(process.cwd(),  "src", "sw.js")],
          outfile: join(process.cwd(),  "dist", "sw.js"),
        });
      },
    },
    compression(),
  ],
  build: {
    minify: "terser",
    outDir: "dist",
    sourcemap: true, // Generate source maps
    rollupOptions: {
      output: {
        manualChunks: {
          // vendor1: [
          //   "moment",
          //   "react-hook-form",
          //   "bootstrap",
          //   "react-bootstrap",
          //   "react-select",
          //   "react-redux",
          //   "react-toastify",
          // ],
          // vendor2: ["axios", "redux-persist", "framer-motion"],
          // vendor3: ["yup"],
        },
        assetFileNames: (assetInfo) => {
          let extType = assetInfo.name.split(".").at(1);
          if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(extType)) {
            extType = "img";
          } else if (/js/i.test(extType)) {
            extType = "js";
          } else if (/json/i.test(extType)) {
            extType = "json";
          }
          return `${extType}/[name]-[hash][extname]`;
        },
        chunkFileNames: "js/[name]-[hash].js",
        entryFileNames: "js/[name]-[hash].js",
      },
    },
    chunkSizeWarningLimit: 9000,
  },
  server: {
    port: 8080,
    host: "0.0.0.0",
  },
});
