import React from "react";
import styled from "styled-components";

// Styled components
const Container = styled.div`
  font-family: "Roboto", sans-serif;
  text-align: left;
  padding: 50px;
  position: relative;
  overflow: hidden;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #f0f0f0; /* Changed background color */
`;

const Card = styled.div`
  background-color: #ffffff; /* Card background color */
  border-radius: 10px;
  padding: 30px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Added box shadow */
`;

const Title = styled.h1`
  font-size: 3rem;
  margin-bottom: 20px;
  color: #333333; /* Changed title color */
  text-align: center;
`;

const GuideStep = styled.p`
  font-size: 1.5rem;
  margin-bottom: 30px;
  color: #555555; /* Changed guide step color */
  text-align: start;
`;

const StepList = styled.ul`
  margin-top: 10px;
  margin-bottom: 20px;
`;

const SubStepList = styled.ul`
  margin-top: 5px;
`;

const SubStep = styled.li`
  list-style-type: square;
`;

const App = () => {
  return (
    <Container>
      <Card className="card">
        <Title>djReact</Title>
        <GuideStep>
          There are two different ways for using djReact, explained below:
        </GuideStep>
        <GuideStep>
          <strong>1. Run Backend and Frontend Separately:</strong> In this
          approach, you run the backend (Django) server and the frontend (React)
          development server as two separate processes. You develop and test the
          frontend and backend independently, and they communicate through HTTP
          requests.
        </GuideStep>
        <StepList>
          <li>
            <strong>Backend (Django):</strong>
            <SubStepList>
              <SubStep>Navigate to Django project directory.</SubStep>
              <SubStep>
                Run Django server: <code>python manage.py runserver</code>.
              </SubStep>
            </SubStepList>
          </li>
          <li>
            <strong>Frontend (React):</strong>
            <SubStepList>
              <SubStep>Navigate to React project directory.</SubStep>
              <SubStep>
                Run React server: <code>npm run dev</code> or{" "}
                <code>yarn dev</code>.
              </SubStep>
            </SubStepList>
          </li>
          <li>
            <strong>Interaction:</strong> Frontend makes HTTP requests to
            backend API endpoints.
          </li>
        </StepList>
        <GuideStep>
          <strong>2. Serve React Build with Django:</strong> In this approach,
          you build your React application and serve the static files generated
          by the React build process using Django. Django serves both the
          backend API endpoints and the frontend React application. Users access
          your application through Django's server, and Django handles routing
          requests to the appropriate endpoints or static files.
        </GuideStep>
        {/* <GuideStep> */}
          <StepList>
            <li>
              <strong>Build React App:</strong>
              <SubStepList>
                <SubStep>Navigate to React project directory.</SubStep>
                <SubStep>
                  Build React app: <code>npm run build</code> or{" "}
                  <code>yarn build</code>.
                </SubStep>
              </SubStepList>
            </li>
            <li>
              <strong>Run server (Django+React):</strong>
              <SubStepList>
                <SubStep>Navigate to Django project directory.</SubStep>
                <SubStep>
                  Run Django server: <code>python manage.py runserver</code>.
                </SubStep>
              </SubStepList>
            </li>
            <li>
              <strong>Interaction:</strong> Your app is running{" "}
              <code>http://localhost:8000</code> and seamlessly serving react
              build out of the box.
            </li>
          </StepList>
        {/* </GuideStep> */}
      </Card>
    </Container>
  );
};

export default App;
